/* silly pointless RCSID $Id: version.c,v 1.1.1.1 2006-07-11 09:28:07 andy Exp $ */
static const char freeswan_version[] = "1.91";
