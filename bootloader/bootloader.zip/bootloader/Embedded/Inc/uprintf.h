#ifndef __UPRINTF_H
#define __UPRINTF_H
extern void  uprintf(char *f, ...);
extern void  uputchar(char Ch);
extern int ukbhit(void);
extern int ugetchar(void);
extern int SetNetWrite(int flag);
#endif