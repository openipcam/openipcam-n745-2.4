#ifndef CDEFS_H
#define CDEFS_H
//------------------------------------------------------------------------------
typedef int INT;
typedef int SIGNED;
typedef unsigned int UNSIGNED;
typedef unsigned int UINT;
typedef unsigned int UINT32;
typedef unsigned short UINT16;
typedef unsigned char UCHAR;
typedef char CHAR;
typedef int INT;
typedef void VOID;
typedef unsigned long ULONG;
#define NULL	0

//------------------------------------------------------------------------------
#endif
